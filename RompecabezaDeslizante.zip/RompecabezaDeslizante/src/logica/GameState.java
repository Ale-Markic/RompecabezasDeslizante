package logica;

public class GameState {

}
